//var txtRisks = require('../../model/risks');
var api = require('./ctrCommon');
var mongoose = require( 'mongoose' );
var Item = mongoose.model('Item');
var Table = mongoose.model('Table');

var sendJSONresponse = api.sendJSONresponse;
var myRequest = api.myRequest;

// Risks Roles
module.exports.riskRoles = function (req, res) {
    var response = {};
	Item
		.find({
			'id': {$in: [
				'rsk_01', 'rsk_02', 'rsk_03', 'rsk_04'
			]}
		})
		.sort({id:1})
		.exec(function (err, item) {
			response.role1 = item[0];
			response.role2 =item[1];
			response.role3 =item[2];
			response.data=item[3];
			sendJSONresponse(res, '200', response);
	})
};

// Risks What
module.exports.riskWhat = function (req, res) {
    //sendJSONresponse(res, '200', txtRisks.txtwhat);
	// rsk_05: gen
	// rsk_06: risks
	// rsk_07: issues
	// rsk_08: risk_conclusion
	// rsk_09: attitude
	// rsk_10: utility
	// rsk_11: Data (global)
};

// Risks Management
module.exports.riskMgt = function (req, res) {
    //sendJSONresponse(res, '200', txtRisks.txtmanagement);
};

// Risks Minimizing
module.exports.riskMini = function (req, res) {
    //sendJSONresponse(res, '200', txtRisks.txtminimizing);
};

// Risks Portfolio & program
module.exports.riskPortfolio = function (req, res) {
    //sendJSONresponse(res, '200', txtRisks.txtPortfolio);
};

// Risks Summary
module.exports.riskSummary = function (req, res) {
    //sendJSONresponse(res, '200', txtRisks.txtSummary);
};

// Risks Versus
module.exports.riskVs = function (req, res) {
    //sendJSONresponse(res, '200', txtRisks.txtvs);
};